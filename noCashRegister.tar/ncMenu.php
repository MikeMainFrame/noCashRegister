<?php

 echo file_get_contents("gs://nclog/ncMenuPrice.json");